package org.example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

public class OrangeHRMTest {

    WebDriver driver;
    WebDriverWait wait;

    LoginPage loginPage;
    DashboardPage dashboardPage;
    AdminUserPage adminUserPage;

    @BeforeClass
    public void setUp() {

        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://opensource-demo.orangehrmlive.com/");

        wait = new WebDriverWait(driver, Duration.ofSeconds(60));

        loginPage = new LoginPage(driver, wait);
        dashboardPage = new DashboardPage(driver, wait);
        adminUserPage = new AdminUserPage(driver, wait);

        loginPage.login("Admin", "admin123");
        Assert.assertTrue(dashboardPage.isDashboardDisplayed(),
                "Dashboard not displayed after login");
    }

    @Test(priority = 1)
    public void TC01_verifyDashboard() {
        Assert.assertTrue(dashboardPage.isDashboardDisplayed(),
                "Dashboard not visible");
    }

    @Test(priority = 2)
    public void TC02_openAdmin() {
        dashboardPage.clickAdmin();
        adminUserPage.waitForUsersPage();
    }

    @Test(priority = 3, dependsOnMethods = "TC02_openAdmin")
    public void TC03_searchUser() {

        adminUserPage.enterUsername("james08");
        adminUserPage.selectUserRole("ESS");
        adminUserPage.selectEmployeeName();
        adminUserPage.selectStatus("Enabled");
        adminUserPage.clickSearch();

        Assert.assertTrue(adminUserPage.isUserFound(),
                "User not found in Admin table");
    }

    @Test(priority = 4, dependsOnMethods = "TC03_searchUser")
    public void TC04_takeScreenshot() {
        ScreenshotUtil.takeScreenshot(driver, "USER_FOUND");
    }

    @Test(priority = 5)
    public void TC05_backToDashboard() {
        dashboardPage.clickDashboard();
        Assert.assertTrue(dashboardPage.isDashboardDisplayed(),
                "Failed to return to Dashboard");
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}