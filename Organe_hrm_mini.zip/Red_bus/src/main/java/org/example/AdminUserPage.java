package org.example;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

public class AdminUserPage {

    // ================= 1. CONSTRUCTOR =================
    private WebDriver driver;
    private WebDriverWait wait;

    public AdminUserPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    // ================= 2. LOCATORS =================
    private By pageHeader =
            By.xpath("//h5[normalize-space()='System Users']");

    private By searchBtn =
            By.xpath("//button[normalize-space()='Search']");

    private By usernameInput =
            By.xpath("//label[normalize-space()='Username']/following::input[1]");

    private By employeeInput =
            By.xpath("//input[@placeholder='Type for hints...']");

    private By tableBody =
            By.xpath("//div[contains(@class,'oxd-table-body')]");

    private By tableRows =
            By.xpath("//div[contains(@class,'oxd-table-row')]");

    private By noRecordsText =
            By.xpath("//span[normalize-space()='No Records Found']");

    // ================= 3. ACTION METHODS =================

    // ---------- Page Load ----------
    public void waitForUsersPage() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(pageHeader));
        wait.until(ExpectedConditions.elementToBeClickable(searchBtn));
    }

    // ---------- Dropdown (User Role / Status) ----------
    private void selectDropdown(String label, String value) {

        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//label[normalize-space()='" + label + "']" +
                        "/following::div[contains(@class,'oxd-select-text')][1]")
        ));
        dropdown.click();

        wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//div[@role='listbox']//span[normalize-space()='" + value + "']")
        )).click();
    }

    public void selectUserRole(String role) {
        selectDropdown("User Role", role);
    }

    public void selectStatus(String status) {
        selectDropdown("Status", status);
    }

    // ---------- Username ----------
    public void enterUsername(String username) {
        WebElement input = wait.until(ExpectedConditions.elementToBeClickable(usernameInput));
        input.clear();
        input.sendKeys(username);
    }

    // ---------- Employee Name (AUTO-SUGGEST FIXED) ----------
    public void selectEmployeeName() {

        WebElement input = wait.until(ExpectedConditions.elementToBeClickable(employeeInput));
        input.clear();
        input.sendKeys("j");

        wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[@role='listbox']")
        ));

        List<WebElement> options = wait.until(
                ExpectedConditions.presenceOfAllElementsLocatedBy(
                        By.xpath("//div[@role='listbox']//span")
                )
        );

        for (WebElement option : options) {
            if (option.getText().trim().equalsIgnoreCase("James Butler")) {
                option.click();
                return;
            }
        }

        // If exact name not found → FAIL clearly
        throw new RuntimeException("Employee 'James Butler' not found in auto-suggest");
    }

    // ---------- Search ----------
    public void clickSearch() {
        wait.until(ExpectedConditions.elementToBeClickable(searchBtn)).click();
    }

    // ---------- RESULT VALIDATION (CRITICAL FIX) ----------
    public boolean isUserFound() {

        // wait for table to load
        wait.until(ExpectedConditions.presenceOfElementLocated(tableBody));

        // If "No Records Found" is displayed → USER NOT FOUND
        if (driver.findElements(noRecordsText).size() > 0) {
            return false;
        }

        // Otherwise → user exists
        return driver.findElements(tableRows).size() > 0;
    }
}
