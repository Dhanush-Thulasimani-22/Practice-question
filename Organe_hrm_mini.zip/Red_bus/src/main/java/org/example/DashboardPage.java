package org.example;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DashboardPage {

    // ---------- 1. Constructor ----------
    private WebDriver driver;
    private WebDriverWait wait;

    public DashboardPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    // ---------- 2. Locators ----------
    private By dashboardHeader = By.xpath("//h6[text()='Dashboard']");
    private By adminMenu = By.xpath("//span[normalize-space()='Admin']");
    private By dashboardMenu = By.xpath("//span[normalize-space()='Dashboard']");

    // ---------- 3. Action Methods ----------
    public boolean isDashboardDisplayed() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(dashboardHeader))
                .isDisplayed();
    }

    public void clickAdmin() {
        WebElement admin = wait.until(ExpectedConditions.elementToBeClickable(adminMenu));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", admin);
        wait.until(ExpectedConditions.urlContains("/admin"));
    }

    public void clickDashboard() {
        wait.until(ExpectedConditions.elementToBeClickable(dashboardMenu)).click();
    }
}